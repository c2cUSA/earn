# C2C Earn — Static Launch Page

This patch pack provides a **static, GitHub Pages–compatible** launch site for `earn.codetocapital.us` using the **C2C Branding Guide v2.0**.

> GitHub Pages hosts static files only. **Do not** place Node/Express backend code here. Deploy your APIs on Render/Railway/etc and point a subdomain (e.g. `earn-api.codetocapital.us`) to it.

## Files
- `index.html` — Landing page (dark theme, neon accents, responsive)
- `style.css` — Brand styling
- `assets/c2c-logo.svg` — Vector logo
- `CNAME` — Sets the custom domain to `earn.codetocapital.us`
- `robots.txt` — Allows search engines
- `README.md` — You are here
- `apply.sh` — Bash helper to copy into an existing repo

## Quick Apply (bash)
Run from the root of your repo (the branch used for Pages, usually `main`). This **overwrites existing** files with the same names in place.

```bash
bash apply.sh
git add -A && git commit -m "chore(pages): add C2C Earn static launch page" && git push origin main
```

If your Pages source is a `/docs` folder, either:
- Move these files to `/docs`, or
- Change the repository Pages settings to **root**.

## GitHub Pages Settings
1. Repo → **Settings → Pages**
2. **Source:** `Deploy from a branch`
3. **Branch:** `main` / `(root)`
4. Custom domain: `earn.codetocapital.us` (this CNAME file helps)
5. Wait for DNS to finish; then tick **Enforce HTTPS**

## Cloudflare DNS (for `codetocapital.us`)
Create a **CNAME** record:
- **Name:** `earn`
- **Target:** `c2cusa.github.io`
- **Proxy:** **Off** (DNS only) until HTTPS is issued, then you may enable proxy if desired.

> If you use the apex `A`/`AAAA` with GitHub, keep them as-is. Only the subdomain needs the CNAME.

## Verify
- Visit: `https://earn.codetocapital.us`
- Page should render with neon-green theme and “Made in USA” badge.
- View source: no Node/Express code present.

## Troubleshooting
- **I still see raw JS text:** You’re on the wrong branch/folder, or the file path is not at the Pages root.
- **HTTPS toggle disabled:** DNS not finished. Wait, then refresh and enable.
- **Old content cached:** Hard refresh or invalidate Cloudflare cache for the subdomain.
