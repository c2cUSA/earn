#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(pwd)"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[C2C] Applying static launch page to $ROOT_DIR"
install -Dm644 "$SRC_DIR/index.html" "$ROOT_DIR/index.html"
install -Dm644 "$SRC_DIR/style.css" "$ROOT_DIR/style.css"
mkdir -p "$ROOT_DIR/assets"
install -Dm644 "$SRC_DIR/assets/c2c-logo.svg" "$ROOT_DIR/assets/c2c-logo.svg"
install -Dm644 "$SRC_DIR/robots.txt" "$ROOT_DIR/robots.txt"
install -Dm644 "$SRC_DIR/CNAME" "$ROOT_DIR/CNAME"
echo "[C2C] Done. Commit & push to update GitHub Pages."
